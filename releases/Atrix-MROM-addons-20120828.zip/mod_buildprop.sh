#!/sbin/sh
# mmontuori Atrix-MROM
if ! busybox grep "ro.service.swiqi.supported=true" /system/build.prop >/dev/null; then
	busybox echo "" >> /system/build.prop
	busybox echo "ro.service.swiqi.supported=true" >> /system/build.prop
fi
if ! busybox grep "persist.service.swiqi.enable=1" /system/build.prop >/dev/null; then
	busybox echo "" >> /system/build.prop
	busybox echo "persist.service.swiqi.enable=1" >> /system/build.prop
fi
if ! busybox grep "ro.semc.sound_effects_enabled=true" /system/build.prop >/dev/null; then
	busybox echo "" >> /system/build.prop
	busybox echo "ro.semc.sound_effects_enabled=true" >> /system/build.prop
	busybox echo "ro.semc.xloud.supported=true" >> /system/build.prop
	busybox echo "persist.service.xloud.enable=1" >> /system/build.prop
fi
